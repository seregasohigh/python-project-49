### Hexlet tests and linter status:
[![Actions Status](https://github.com/seregasohigh/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/seregasohigh/python-project-49/actions)
<a href="https://codeclimate.com/github/seregasohigh/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b067ed48db53282d0b36/maintainability" /></a>